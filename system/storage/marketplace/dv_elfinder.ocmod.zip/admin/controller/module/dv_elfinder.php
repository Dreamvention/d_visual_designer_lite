<?php

namespace Opencart\Admin\Controller\Extension\DvElfinder\Module;

class DvElfinder extends \Opencart\System\Engine\Controller {
    private $error = array();

    public function connector()
    {
        require_once(DIR_EXTENSION . 'dv_elfinder/system/library/dv_elfinder/connector.php');

        header('Access-Control-Allow-Origin: *');
        $connector = new \elFinderConnector(new \elFinder($opts), true);
        $connector->run();
    }

}
