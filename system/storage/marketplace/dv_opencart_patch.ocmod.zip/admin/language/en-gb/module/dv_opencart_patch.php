<?php
$_['heading_title']                 = '<span style="color:#449DD0; font-weight:bold">Opencart Patch</span><span style="font-size:12px; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span>';
$_['heading_title_main']            = 'Opencart Patch';