<?php
namespace Opencart\Admin\Controller\Extension\DvOpencartPatch\Module;

class DvOpencartPatch extends \Opencart\System\Engine\Controller {
    public function install (): void {
        
    }
}