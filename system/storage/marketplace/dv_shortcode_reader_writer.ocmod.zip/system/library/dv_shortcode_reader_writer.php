<?php

namespace Opencart\System\Library\Extension\DvShortcodeReaderWriter;
use Opencart\System\Library\Extension\DvShortcodeReaderWriter\DvShortcodeReader;
use Opencart\System\Library\Extension\DvShortcodeReaderWriter\DvShortcodeWriter;

class DvShortcodeReaderWriter
{
    private $writer;
    private $reader;

    public function __construct($items, $prefix='vd')
    {
        $this->reader = new DvShortcodeReader($items, $prefix);
        $this->writer = new DvShortcodeWriter($prefix);
    }

    public function readShortcode($text)
    {
        return $this->reader->readShortcode($text);
    }

    public function writeShortcode($setting)
    {
        return $this->writer->writeShortcode($setting);
    }

    public function escape($text)
    {
        return $this->writer->escape($text);
    }
}
