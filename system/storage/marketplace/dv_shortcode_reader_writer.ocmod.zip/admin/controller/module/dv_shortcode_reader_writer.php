<?php
namespace Opencart\Catalog\Controller\Extension\DvShortcodeReaderWriter\Module;

class DvShortcodeReaderWriter extends \Opencart\System\Engine\Controller {
    public function install (): void {

    }
}
